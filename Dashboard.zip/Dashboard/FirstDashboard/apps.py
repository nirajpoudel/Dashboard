from django.apps import AppConfig


class FirstdashboardConfig(AppConfig):
    name = 'FirstDashboard'
